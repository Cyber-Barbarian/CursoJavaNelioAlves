package Cap06.programa01;

import java.util.Scanner;

public class WhileMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite um número inteiro menor que 10");
        Integer x = sc.nextInt();

        while (x<10){
            System.out.println("x = " + x);
            x+=1;
        }
        System.out.println("Limite atingido: x = " + x);
        sc.close();

    }
}
