package Cap09.programa04.src.entities;

public class Product {

    //Encapsulamento: O objeto deve sempre estar em um estado consistente, e a própria classe deve garantir isso.
    //Usamos portanto o método private para esconder atributos de um objeto.
    private String name;
    private double price;
    private int quantity;

    //para acessar agora os atributos de um objeto, vamos settar getters e setter.
    //por convenção, são setados após os construtores.
    //Construtores:
    public Product(String name, double price, int quantity) {
        this.setName(name);
        this.setPrice(price);
        this.setQuantity(quantity);
    }

    public Product() {
    }

    public Product(String name) {
        this.setName(name);
    }

    //Getters(pegar a variavel) e setters(setar a variavel)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }
    //Não vamos criar o set quantity pois queremos que a quantidade seja alterada somente pelos métodos

    //OBS: getters e setters podem ser gerados automaticamente clicando com o botão direito na classe
    //tanto no eclipse quanto no intelij.
    // no eclipse
    // Botão direito -> Source -> Generate Constructor using Fields
    // Botão direito -> Source -> Generate Getters and Setters
    //no intelij : refactor -> encapsulate fields

    //métodos
    public double totalValueInStock() {
        return getPrice() * getQuantity();
    }

    public void addProducts(int quantity) {
        this.setQuantity(this.getQuantity() + quantity);
    }

    public void removeProducts(int quantity) {
        this.setQuantity(this.getQuantity() - quantity);
    }

    public String toString() {
        return getName()
                + ", $ "
                + String.format("%.2f", getPrice())
                + ", "
                + getQuantity()
                + " units, Total: $ "
                + String.format("%.2f", totalValueInStock());
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}

