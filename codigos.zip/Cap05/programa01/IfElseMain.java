package Cap05.programa01;

import java.util.Scanner;

public class IfElseMain {

    public static void main(String[] args) {
        /*Uma operadora de telefonia cobra R$ 50.00 por um plano básico que
        dá direito a 100 minutos de telefone. Cada minuto que exceder a
        franquia de 100 minutos custa R$ 2.00. Fazer um programa para ler a
        quantidade de minutos que uma pessoa consumiu, daí mostrar o valor
        a ser pago*/
        Scanner sc = new Scanner(System.in);
        Integer franquia = 100,minutosUso,minutoExcedente;
        Double precoFranquia = 50.00, precoMinutoExcedente=2.00, conta;


        System.out.println("Quantos minutos utilizou-se o telefone este mês? (em inteiros)");
        minutosUso = sc.nextInt();
        sc.nextLine();

        if(minutosUso>franquia){
            minutoExcedente = minutosUso - franquia;
        }
        else{
            minutoExcedente = 0;
        }
        conta = precoFranquia + precoMinutoExcedente*minutoExcedente;

        System.out.printf("%nO valor da conta será de R$ %.2f.%n",conta);

        sc.close();


    }
}
