package Cap04;

public class testeMain {
    public static void main(String[] args) {
        System.out.println("teste");
    }
    
}
