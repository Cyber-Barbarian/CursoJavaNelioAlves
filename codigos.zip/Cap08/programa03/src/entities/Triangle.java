package Cap08.programa03.src.entities;

public class Triangle {
    //atributos
    public double a;
    public double b;
    public double c;

    //metodo
    //não precisamos declarar parâmetros nesse método/função pois ela é inerente à classe
    //ou seja, ela é capaz de ler os atributos da classe. Está atrelada a ela.
    //como não tem static, é preciso instanciar o objeto antes

    public double area(){
        double p = (a + b + c) / 2.0;
        return Math.sqrt(p * (p - a) * (p - b) * (p - c));
    }

    //com static -> a função pode ser chamada sem instanciar objeto, mas passa a depender de
    //parâmetros claros. pode ser chamada de maneira direta.
    public static double areaTeste(double a,double b, double c){
        double p = (a + b + c) / 2.0;
        return Math.sqrt(p * (p - a) * (p - b) * (p - c));
    }



}
