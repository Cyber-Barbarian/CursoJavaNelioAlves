package Cap08.programa03.src.application;
//importando a classe triangle
import Cap08.programa03.src.entities.Triangle;

import java.util.Locale;
import java.util.Scanner;


public class AreaTrianguloComObjetoMain {
    public static void main(String[] args) {
        double areaZ = Triangle.areaTeste(4.0,2.0,3.0);
        System.out.println("Triangle.areaTeste: Função publica e estática, ou seja," +
                "pode ser acessada de qualquer lugar, bastando importar, " +
                "e não necessita da criação de um objeto. \n Tem seus próprios atributos.");
        System.out.println("areaZ = "+areaZ);

        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);

        System.out.println("Triangle.area: Função publica e não estática, ou seja," +
                "pode ser acessada de qualquer lugar, bastando importar. " +
                "NECESSITA da criação de um objeto. \n Acessa os atributos" +
                " dos objetos criado.");

        //criando as variáveis do tipo Triangle
        Triangle x, y;
        //instanciando a classe, criando os objetos para poder ser usados
        x = new Triangle();
        y = new Triangle();

        System.out.println("Enter the measures of triangle X: ");
        x.a = sc.nextDouble();
        x.b = sc.nextDouble();
        x.c = sc.nextDouble();
        System.out.println("Enter the measures of triangle Y: ");
        y.a = sc.nextDouble();
        y.b = sc.nextDouble();
        y.c = sc.nextDouble();

        double areaX = x.area();
        double areaY = y.area();
        System.out.printf("Triangle X area: %.4f%n", areaX);
        System.out.printf("Triangle Y area: %.4f%n", areaY);
        if (areaX > areaY) {
            System.out.println("Larger area: X");
        }
        else {
            System.out.println("Larger area: Y");
        }



        sc.close();

    }
}
