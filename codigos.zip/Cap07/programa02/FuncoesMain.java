package Cap07.programa02;

import java.util.Locale;
import java.util.Scanner;

public class FuncoesMain {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);//antes do scanner

        Scanner sc = new Scanner(System.in);
        System.out.println("Digite 3 números:");

        double a = sc.nextDouble();
        sc.nextLine();
        double b = sc.nextDouble();
        sc.nextLine();
        double c = sc.nextDouble();
        sc.nextLine();

        //aplicando a função
        double maximo = max(a,b,c);
        showResult(maximo);

        sc.close();
    }
    //public deixa uma função disponível em outras classes
    //static permite que a função seja chamada independentemente de se criar um objeto
    //escopo + característica + tipo  de saída + nome + variável
    public static double max(double x, double y, Double z) {

        double aux; // escopo local
        if (x > y & x > z) {
            aux = x;
        } else if (y > z) {
            aux = y;
        } else {
            aux = z;
        }
        return aux;//retorno
    }
    //quando uma função retorna uma ação, mas não um dado, o seu tipo é "vazio", ou seja void

    public static void showResult(double value){
        System.out.println("O maior valor é "+value);

    }

}
