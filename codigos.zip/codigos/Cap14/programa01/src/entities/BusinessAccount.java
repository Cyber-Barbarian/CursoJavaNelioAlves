package Cap14.programa01.src.entities;

public class BusinessAccount extends Account {
    private Double loanLimit;

    public BusinessAccount() {
        super();//super serve para executar a lógica de construtor da classe base (super classe)
    }


    public BusinessAccount(Integer number, String holder, Double balance, Double loanLimit) {
        super(number, holder, balance);//esse último construtor foi criado com a chamada do construtor da super classe
        this.loanLimit = loanLimit;
    }

    public Double getLoanLimit() {
        return loanLimit;
    }

    public void setLoanLimit(Double loanLimit) {
        this.loanLimit = loanLimit;
    }

    public void loan(double amount){
        if (amount <= loanLimit) {
            //deposit(amount);
            balance += amount;
        }
    }


    public String toStringBusiness() {
        final StringBuilder sb = new StringBuilder("BusinessAccount{");
        sb.append("loanLimit=").append(loanLimit);
        sb.append('}');
        return super.toString() + sb.toString();
    }
}
