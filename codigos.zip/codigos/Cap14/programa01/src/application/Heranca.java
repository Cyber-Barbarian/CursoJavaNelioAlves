package Cap14.programa01.src.application;

import Cap14.programa01.src.entities.BusinessAccount;

public class Heranca {
    public static void main(String[] args) {

        BusinessAccount ba = new BusinessAccount(12345,"Pedro",200.00,1000.00);
        //se fizermos "ba." vamos ver que conseguimos acessar tudo que foi criado em Account. Herannça.

        ba.deposit(200.00);
        ba.withdraw(10.00);
        ba.loan(600.00);

        System.out.println(ba.toString());
        System.out.println(ba.toStringBusiness());

    }
}
