package Cap04.programa03;

import java.util.Locale;
import java.util.Scanner;

public class EntradaDados01Main {
    public static void main(String[] args){
        //Usaremos uma variável Scanner
        Locale.setDefault(Locale.US);//antes do scanner
        Scanner sc = new Scanner(System.in);
        String x;
        Integer y;
        Double z;
        char w;

        System.out.println("Digite uma palavra");
        x = sc.next();
        System.out.println("Você digitou "+x);

        System.out.println("Digite um número inteiro");
        y = sc.nextInt();
        System.out.println("Você digitou "+y);

        System.out.println("Digite um número com ponto flutuante");
        z = sc.nextDouble();
        System.out.printf("Você digitou %.2f%n",z);

        System.out.println("Digite um caractere ou palavra");
        w = sc.next().charAt(0);
        System.out.println("Primeiro Char "+w);

        sc.close();
        //sempre usar

    }
}
