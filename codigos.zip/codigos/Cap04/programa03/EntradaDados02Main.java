package Cap04.programa03;

import java.util.Scanner;

public class EntradaDados02Main {
    public static void main(String[] args) {
        //Para lermos uma string té a quebra de linha usamos sc.nextLine()
        Scanner sc = new Scanner(System.in);
        String s1,s2,s3;
        Integer x;

        System.out.println("digite um número e tres palavras/frases, dando ENTER após cada um:");
        x = sc.nextInt();
        sc.nextLine();
        //se não deixarmos esse sc.nextLine() o ENTER fica preso na entrada padrão e entrará como string vazia s1, causando bug
        //ou seja: o sc.nextLine() deve ser usado após tudo que não é sc.nextLine para limpar o buffer de leitura
        s1 = sc.nextLine();
        s2 = sc.nextLine();
        s3 = sc.nextLine();

        System.out.println("Dados digitados:");
        System.out.println(x);
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);

        sc.close();



    }
}
