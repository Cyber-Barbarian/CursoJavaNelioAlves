package Cap04.programa02;

public class CastMain {
    public static void main(String[] args){
        //O java tenta fazer a conversão de acordo com os dados de entrada de uma expressão
        int x, y,a;
        double resultado;
        x=5;
        y=2;
        resultado = x/y;
        System.out.println("O resultado é: " + resultado);

        //O java fez a conversão para inteiro devido aos dados de entrada.
        // Para termos o resultado como double precisamos fazer cast da expressão:
        resultado = (double) x/y;
        System.out.println("O resultado correto é: " + resultado);


        //E se tentarmos atribuir double a um inteiro?
        a = (int) resultado;
        System.out.printf("%nSe removermos o cast (int) de 'a' veremos que " +
                "não vai funcionar.%na= %d", a);


    }
}
