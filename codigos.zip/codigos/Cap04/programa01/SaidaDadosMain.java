package Cap04.programa01;

import java.util.Locale;

public class SaidaDadosMain {
    public static void main(String[] args){
        //declarado variáveis
        int y = 32;
        double pi = 3.14159265358979323846;
        String nome = "Maria";
        int idade = 33;
        double renda = 7000.0;

        //printando dados
        System.out.println("Olá");
        System.out.print("Olá");
        System.out.println("Olá");

        System.out.println("y: "+y);

        //formataçãop de saída: printf
        //%f -> ponto flutuante
        //%d -> inteiro
        //%s -> texto
        //%n quebra de linha

        System.out.print("pi: " + pi);
        System.out.printf("%npi com quebra de linha e 2 casas: %.2f %n",pi);

        //mudando localidade
        System.out.println("Mudando para ponto no lucar de vírgula: ");
        Locale.setDefault(Locale.US);
        System.out.printf("%.2f%n",pi);

        //concatenando vários elementos
        System.out.printf("%nPodemos exibir pi com 2 casas decimais%npi = %.4f",pi);

        //concatenando vários elementos de tipos distintos
        System.out.printf("%n%n%s tem %d anos.%nA renda de %s é de cerca de %.2f reais",nome,idade,nome,renda);







    }
}
