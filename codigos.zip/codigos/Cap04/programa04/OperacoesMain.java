package Cap04.programa04;

public class OperacoesMain {
    public static void main(String[] args) {
        double x = 3.0;
        double y = 4.0;
        double z = -5.0;
        double A,B,C;

        //Em java usamos o modulo Math
        //Raiz quadrada
        A = Math.sqrt(x);
        B = Math.sqrt(y);
        C = Math.sqrt(25.0);
        System.out.printf("Raízes de 5, 4 e 25 são %n%.2f%n%.2f%n%.2f%n",A,B,C);

        //Potência
        A = Math.pow(x,y);
        B = Math.pow(y,2.0);
        C = Math.pow(z,3);
        System.out.printf("%.2f elevado a %.2f é %.2f%n",x,y,A);
        System.out.printf("%n%.2f elevado a %.2f é %.2f%n",y,2.0,B);
        System.out.printf("%n%.2f elevado a %d é %.2f%n",z,3,C);

        //absoluto
        A = Math.abs(y);
        B = Math.abs(z);
        System.out.println("Valor absoluto de " + y + " = " + A);
        System.out.println("Valor absoluto de " + z + " = " + B);

    }
}
