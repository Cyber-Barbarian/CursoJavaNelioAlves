#Dicas para resolver

- Começar pelas entidades Department e HourContract, criando as variáveis manualmente e os construtores, getters e setter de forma automática
- WorkerLevel vai ser um tipo enumerado. Quando for criar se atentar a isso
- Worker será mais uma entidade, onde ficará sintetizada a relação com as classes anteriores. É nela que ficam registradas as associações.
- Em Worker, se atentar que o construtor não inclui as variáveis do tipo lista 
  - Em Worker tb não temos o setContracts, pois não queremos sobreposição ao nosso método
  - Em Worker usamos a função calendar para acessar mês e ano. Em java os meses vão de 0 a 11, não de 1 a 12
- throws ParseException -> throws significa que o programa passa a aceitar esse tipoo de exception