package Cap13.programa02exemplo.src.entities.enums;

public enum WorkerLevel {
    JUNIOR,
    MID_LEVEL,
    SENIOR
}
