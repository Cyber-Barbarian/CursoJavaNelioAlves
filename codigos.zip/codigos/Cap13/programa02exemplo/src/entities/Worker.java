package Cap13.programa02exemplo.src.entities;

import Cap13.programa02exemplo.src.entities.enums.WorkerLevel;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Worker {
    //atributos básicos
    private String name;
    private WorkerLevel level;
    private Double baseSalary;
    //associações
    //cada trabalhador terá um único departamento
    private Department department;
    //cada trabalhador pode ter vários contratos
    private final List<HourContract> contracts = new ArrayList<>();

    //construtores
    public Worker() {
    }

    // no caso de classes contendo construtores, havendo uma lista nós não incluímos ela no construtor,
    // mas sim iniciamos ela na declaração. por ex: new ArrayList<>()
    //assim qualquer objeto do tipo Worker já inicia com uma lista vazia para que possamos inserir/remover

    public Worker(String name, WorkerLevel level, Double baseSalary, Department department) {
        this.name = name;
        this.level = level;
        this.baseSalary = baseSalary;
        this.department = department;
    }

    //getters e setters

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public WorkerLevel getLevel() {
        return level;
    }

    public void setLevel(WorkerLevel level) {
        this.level = level;
    }

    public Double getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(Double baseSalary) {
        this.baseSalary = baseSalary;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartament(Department department) {
        this.department = department;
    }

    public List<HourContract> getContracts() {
        return contracts;
    }

    //removemos o setContracts pois não queremos sobreposição ao nosso método
    //métodos
    public void addCotract(HourContract contract) {
        //simplesmente adiciona um contrato na lista
        contracts.add(contract);
    }

    public void removeContract(HourContract contract) {
        //simplesmente remove da lista
        contracts.remove(contract);
    }

    public double income(int year, int month) {
        double sum = baseSalary;
        Calendar cal = Calendar.getInstance();
        for (HourContract c : contracts) {
            cal.setTime(c.getDate());
            int c_year = cal.get(Calendar.YEAR);
            int c_month = cal.get(Calendar.MONTH) + 1;//em java os meses vão de 0 a 11, não de 1 a 12
            if (c_year == year && c_month == month) {
                sum += c.totalValue();
            }
        }
        return sum;
    }

    @Override
    public String toString() {
        return "Worker{" +
                "name='" + name + '\'' +
                ", level=" + level +
                ", baseSalary=" + baseSalary +
                ", department=" + department.getName() +
                '}';
    }
}
