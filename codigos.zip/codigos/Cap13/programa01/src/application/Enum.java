package Cap13.programa01.src.application;

import Cap13.programa01.src.entities.Order;
import Cap13.programa01.src.entities.enums.OrderStatus;


import java.util.Date;
import java.lang.Thread;

public class Enum {
    public static void main(String[] args) {

        Order order = new Order(10, new Date(), OrderStatus.PENDING_PAYMENT);

        System.out.println(order.toString());//toString gerado automaticamente em Order

        //alterando a order depois de 2 segundos
        try
        {
            Thread.sleep(2000);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        System.out.println("new status");
        order.setId(order.getId());
        order.setMoment(new Date());
        order.setStatus(OrderStatus.PROCESSING);
        System.out.println(order.getId());
        System.out.println(order.getMoment());
        System.out.println(order.getStatus());

        //Pegando o valor de status de uma string, como se fosse um input de usuário
        OrderStatus os1 = OrderStatus.SHIPPED;
        OrderStatus os2 = OrderStatus.valueOf("DELIVERED");//pegando de string, podia ser um scanner

        //alterando a order depois de 2 segundos
        try
        {
            Thread.sleep(2000);
            order.setStatus(os1);
            order.setMoment(new Date());
            System.out.println(order.toString());

        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        //alterando a order depois de 2 segundos
        try
        {
            Thread.sleep(2000);
            order.setStatus(os2);
            order.setMoment(new Date());
            System.out.println(order.toString());

        }
        catch(Exception e)
        {
            System.out.println(e);
        }


    }
}
