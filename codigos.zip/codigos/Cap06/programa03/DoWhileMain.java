package Cap06.programa03;

import java.util.Scanner;

public class DoWhileMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char resp;
        Integer x;

        do{
            System.out.println("Digite um número ");
            x = sc.nextInt();
            sc.nextLine();
            System.out.println("x = " + x);
            System.out.println("deseja continuar? (s/n)");
            resp = sc.nextLine().charAt(0);
        }while (resp ==  's');

        System.out.println("FIM");
        sc.close();

    }
}
