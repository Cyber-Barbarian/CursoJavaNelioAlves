package Cap06.programa02;

import java.util.Scanner;

public class ForMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("digite um número de 1 a 10");
        Integer x = sc.nextInt();

        for (Integer i = 0; i<=x && i<=10; i+=2 ){
            System.out.println("i = " + i);
        }

        System.out.println("Fim");

        sc.close();

    }
}
