#Resumo e anotações por capítulo

# Cap 02

## Tipos de linguagens:
- Código fonte: é aquele escrito pelo programador em linguagem de programação;

- Linguagens Compiladas: Nesta estratégia, os softwares que realizam a tradução e a execução atuam em fases separadas do processo. O software que realiza a tradução, chamado compilador, traduz todo o código fonte de uma vez e produz um arquivo em linguagem de máquina, chamado código objeto. Este arquivo fica armazenado no computador e é processado pelo executável quando o usuário resolve executar o programa. Um ponto de atenção aqui é que para cada máquina diferente é necessário compilar um binário diferente. Ex: linguagem C e C++;

  ```mermaid
  graph LR
  A[Código Fonte] -->|Compilador|B[Código Objeto] -->|Gerador de código: build|C[Código Executável] -->D[Execução]
  
  ```
- Linguagens Interpretadas: Nesta estratégia, o software que comanda a tradução também comanda a execução do programa. Tal software é chamado interpretador. Ele faz a leitura de cada linha do código fonte, traduz em linguagem de máquina os comandos correspondentes, e executa estes comandos. Aqui o interpretador O interpretador por sua vez faz a comunicação com a máquina onde está executando o código, mas ele que faz todo o restante do trabalho ao invés de você precisar compilar, para cada máquina um binário diferente. Ex: JavaScript, Python.
  ```mermaid
  graph LR
  A[Código Fonte] -->|Interpretador|B[Execução]
  
  ```
- Linguagens Híbridas: O método híbrido, representa um meio termo entre os compiladores e os interpretadores. Ele traduz (compila) os programas em linguagem de alto nível para uma linguagem intermediária projetada para facilitar a interpretação. Depois, usa um interpretador. Um exemplo é o Java, que tem um compilador que converte seu código para bytecode e na sequência isso é lido para JVM (Java Virtual Machine) que é basicamente um interpretador, para no final ser executado pelo CPU, não necessitando assim de diferentes binários para cada máquina. Ex: Java, C#;
  ```mermaid
  graph LR
  A[Código Fonte] -->|Compilador:pré compilação|B[Bytecode] -->|Máquina Virtual: interpretação|C[Execução]
  
  ```

    
## Vantagens:
- Compilação: velocidade do programa, auxílio do compilador antes da execução
- Interpretação: flexibilidade de manutenção do aplicativo em produção, expressividade da linguagem,  código fonte não precisa ser recompilado para rodar em plataformas diferentes
- Abordagem híbrida: reúne todas as vantagens acima

# Cap 03
## Aspectos do Java
- Código compilado para Bytecode e executado em uma JVM
- Portável, segura, robusta
- Roda em vários tipos de dispositivos e sistemas operacionais sem alteração
- Domina o mercado corporativo desde o fim do século 20
- Padrão Android por muitos anos
- LTS - Long Term Support
- Java ME - Micro Edition - para disositivos embarcados e móveis - IoT
- Java SE - Standard Edition - core - desktop e servidores
- Java EE - Enterprise Edition - aplicações corporativas

#Cap 04
##Operadores Java

| Operadores    | Significado             |
| ------------- | ----------------------- |
| +             | Adição                  |
| -             | Subtração               |
| *             | Multiplicação           |
| /             | Divisão                 |
| %             | Resto da divisão (mod)  |


| Descrição  | Tipo |Tamanho|Valores|Valor Padrão|
| ------------- | -------------- |---|---|---|
| tipos numéricos inteiros | byte<br>short<br>int<br>long |8 bits<br>16 bits<br>32 bits<br>64 bits|-128 a 127<br>-32768 a 32767<br>-2147483648 a 2147483647<br>-9223372036854770000 a 9223372036854770000|0<br>0<br>0<br>0L|
| tipos numéricos com ponto flutuante| float<br>double   |32 bits<br>64 bits |-1,4024E-37 a 3,4028E+38 <br> -4,94E-307 a 1,79E+308|0.0f<br>0.0|
| um caractere unicode   | char    |16 bits|'\u0000' a '\uFFFF'|'\u0000'|
| valor verdade| boolean |1 bit|{false, true}|false|

String - cadeia de caracteres (palavras ou textos)

##Variáveis
- Uma variável é uma porção de memória (RAM) utilizada para armazenar dados durante a execução dos programas.
- Não pode começar com dígito, não pode ter espaço em branco, não usar acentos ou til.
- As variáveis não devem contar com caracteres especiais em seu nome. As únicas exceções são o underline (_) e o cifrão ($) 
- As variáveis são case-sensitive. Os nomes devem ser declarativos e auto-explicativos. Sugestão Camel case;

##Saída de dados em Java
Sem quebra de linha ao final:
```

    System.out.print("Bom dia!");
```

Com quebra de linha ao final:
```

    System.out.println("Bom dia!");
```

Com formatação de saída:
```

    string teste = "dia";
    System.out.printlf("Bom %s!%n",teste);
//%f = ponto flutuante
//%d = inteiro
//%s = texto
//%n = quebra de linha
```
Exemplo: [Saída de dados](Cap04/programa01/SaidaDadosMain.java)

##Casting
- É a conversão de um tipo para outro, como no exemplo: [Conversão](Cap04/programa01/SaidaDadosMain.java)

##Entrada de dados
- Classe Scanner: Podemos usar a classe Scanner para realizar a entrada de dados a partir do teclado em um programa. Ela precisa ser importada do pacote java.util e usada para criar um objeto de entrada.
- Classe Locale: A classe Locale (do pacote java.util) é usada para representar uma região geograficamente, política ou culturalmente, na qual uma determinada língua é falada ou um determinado costume foi adotado. Ela precisa ser importada do pacote java.util e geralmente iniciada no começo do código.
- Exemplo 1:[Entrada de dados 1](Cap04/programa03/EntradaDados01Main.java); Exemplo 2:[Entrada de dados 2](Cap04/programa03/EntradaDados02Main.java);

##Funções matemáticas em Java
- Em java usamos a classe Math para operações como raiz quadrada, potência, absoluto, funções trigonométricas, constantes como pi, constante de euler, etc...
- Essa classe já está na package (pacote) java.lang. Ou seja, não precisamos importar.
- Exemplo: [Classe Math](Cap04/programa04/OperacoesMain.java)

#Cap 05


#Cap 14
#Herança
- Definição: Associação onde uma classe herda todos os dados e comportamentos de outra
- Vantagens: Reuso e Polimorfismo
- Sintaxe: Classe X extends Y
- Exemplo: [Herança](Cap14/programa01/src/application/Heranca.java)

## Modificador de acesso (protected)
- Quando um membro da classe é public, ele pode ser acessado de qualquer outra classe
- Quando um membro da classe é private, ele só pode ser acessado de dentro da classe
- Quando um membro da classe é protected, esse membro pode ser acessado na própria classe, numa outra classe do mesmo pacote e em outra classe, de outro pacote, que seja uma subclasse.
- Exemplo mudamos de private para protected a variável deposit em  [Herança](Cap14/programa01/src/application/Heranca.java) com a finalidade de poder operar diretamente com esta variável.
 
## Outras definições importantes
- herança é uma relação "é-um": A BusinessAccount é uma Account, com algo mais (extensão)
- A Superclasse ou clase base (Account) é uma generalização, as Subclasses ou classes derivadas (BusinessAccount) uma especialização
- Extensão: as Subclasses estendem as Superclasses
- Diferente da composição, a herança é uma relação entre classes, e não entre objetos. Dessa forma quando se instancia uma subclasse se instancia um objeto só, que vai ter todos os membros da subclasse e superclasse.