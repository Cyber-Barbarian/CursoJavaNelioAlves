#Resumo e anotações por capítulo

- Cap 03
  - 