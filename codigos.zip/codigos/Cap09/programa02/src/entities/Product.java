package Cap09.programa02.src.entities;

public class Product {

    public String name;
    public double price;
    public int quantity;
    //construtores -> impedem a inserção de dados errados , protegendo o código

    public Product(String name, double price, int quantity) {//podia ser outros nomes
        //this é sempre uma referencia ao objeto
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        //vão ser necessários agora argumentos

    }
    //Sobrcarga: É um recurso que uma classe possui de oferecer mais de uma
    //operação com o mesmo nome, porém com diferentes listas de parâmetros.

    public Product(){

    }

    public Product (String name){
        this.name=name;
    }


    public double totalValueInStock() {
        return price * quantity;
    }
    public void addProducts(int quantity) {
        this.quantity += quantity;
    }
    public void removeProducts(int quantity) {
        this.quantity -= quantity;
    }
    public String toString() {
        return name
                + ", $ "
                + String.format("%.2f", price)
                + ", "
                + quantity
                + " units, Total: $ "
                + String.format("%.2f", totalValueInStock());
    }
}

