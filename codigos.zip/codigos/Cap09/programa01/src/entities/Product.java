package Cap09.programa01.src.entities;

public class Product {

    public String name;
    public double price;
    public int quantity;
    //construtores -> impedem a inserção de dados errados , protegendo o código

    public Product (String name, double price, int quantity) {//podia ser outros nomes
        //this é sempre uma referencia ao objeto
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        //vão ser necessários agora argumentos

    }

    public double totalValueInStock() {
        return price * quantity;
    }
    public void addProducts(int quantity) {
        this.quantity += quantity;
    }
    public void removeProducts(int quantity) {
        this.quantity -= quantity;
    }
    public String toString() {
        return name
                + ", $ "
                + String.format("%.2f", price)
                + ", "
                + quantity
                + " units, Total: $ "
                + String.format("%.2f", totalValueInStock());
    }
}

