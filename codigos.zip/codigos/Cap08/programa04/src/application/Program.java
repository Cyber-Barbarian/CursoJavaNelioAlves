package Cap08.programa04.src.application;

import Cap08.programa04.src.entities.Product;

import java.util.Locale;
import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);
        Product product = new Product();
        int quantity;

        System.out.println("Enter product data");
        System.out.println("Name:");
        product.name = sc.next();
        System.out.println("Price:");
        product.price = sc.nextDouble();
        System.out.println("Quantity in stock:");
        product.quantity = sc.nextInt();


        //System.out.printf("Product data: %s, %.2f, %d", product.name, product.price, product.quantity)

        System.out.printf("Product data: %s%n", product);
        //como estamos num contexto de string o java chama o .toString automaticamente quando
        //acessamos products. não precisa fazer product.toString()

        System.out.println();
        System.out.println("Enter  the number of products to be added in stock:");
        quantity = sc.nextInt();
        product.addProducts(quantity);
        System.out.printf("Updated data: %s%n", product);

        System.out.println();
        System.out.println("Enter  the number of products to be removed from stock:");
        quantity = sc.nextInt();
        product.removeProducts(quantity);
        System.out.printf("Updated data: %s%n", product);

        sc.close();
    }
}
