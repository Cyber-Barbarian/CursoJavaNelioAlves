package Cap08.programa04.src.entities;

public class Product {
    //variáveis
    public String name;
    public double price;
    public int quantity;

    //métodos

    public double totalValueInStock(){
        return price*quantity;
    }

    public void addProducts(int quantity){
        //o quantity do argumento é diferente do quantity do escopo global.
        // para acessar o do escopo global usamos a palavra "this"
        this.quantity+=quantity;// para acesar o da variável local, basta chamar
    }
    public void removeProducts(int qunatity){
        this.quantity-=qunatity;
    }

    //criaremos um metodo "toString()" sobrepondo o que ja existe
    public String toString(){
        //return name + ", $ " + price + ", " + quantity + " units, Total: $ " + totalValueInStock();
        //vamos usar o método String.format para garantir a formatação
        return name + ", $ " +
                String.format("%.2f", price) +
                ", " + quantity + " units, Total: $ "
                + String.format("%.2f",totalValueInStock());
    }

}
