package Cap08.programa02.src.entities;

public class Triangle {
    //atributos
    public double a;
    public double b;
    public double c;
}
