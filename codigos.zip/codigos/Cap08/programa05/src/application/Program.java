package Cap08.programa05.src.application;

import Cap08.programa05.src.util.Calculator;

import java.util.Locale;
import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);
        Calculator calc = new Calculator();


        System.out.print("Enter radius: ");
        double radius = sc.nextDouble();
        //acessando um método não estático: precisamos instanciar primeiro um objeto calc
        double c = calc.circumference(radius);
        //acessando um método não estático: não precisamos instanciar primeiro um objeto.
        //Não consegue reconhecer as váriáveis dentro da própria classe. precisa declarar na entrada do metodo.

        double v = Calculator.volume(radius);

        System.out.printf("Circumference: %.2f%n", c);
        System.out.printf("Volume: %.2f%n", v);
        System.out.printf("PI value: %.2f%n", calc.PI);
        System.out.printf("PI (estático) value: %.2f%n", Calculator.PI_STATIC);

        sc.close();
    }
}
