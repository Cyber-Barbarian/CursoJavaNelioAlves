package Cap08.programa05.src.util;

public class Calculator {

    public final double PI = 3.14159; // final siggnifica que é uma constante
    //por padrão, para constantes usamos letra maiúscula

    public static final double PI_STATIC = 3.14159;

    public double circumference(double radius) {
        return 2.0 * PI * radius; // poderia usar PI ou PI_STATIC
    }
    public static double volume(double radius) {
        //Não se consegue usar uma constante ou variável não estática em um método estático
        //pois ela depende de criação de objeto
        return 4.0 * PI_STATIC * radius * radius * radius / 3.0;
    }
}
