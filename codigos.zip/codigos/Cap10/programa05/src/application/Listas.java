package Cap10.programa05.src.application;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Listas {
    public static void main(String[] args) {
        //Criando uma lista: listas são estruturas de dados homogêneas (mesmo tipo)
        //ordenadas, iniciam vazias e onde cada elemento ocupa um nó que aponta para o próximo
        //Ela faz o oposto do array: Tem tamanhop variável, suportam inserções e deleções
        // e o acesso a seus elementos é sequencial
        //Listas não aceitam tipos primitivos!! usar wrapper clases
        List <String> list = new ArrayList<>();
        //List é somente uma interface. O Java não aceita new List. Devemos usar uma classe que implemente
        //a interface List, como ArrayList.

        //adicionando elementos
        list.add("Maria");
        list.add("Alex");
        list.add("Bob");
        list.add("Anna");
        list.add("Peter");
        list.add("Parker");
        //inserir elemento em posição específica
        list.add(2,"Marco");

        //Removendo um elemento com base no valor
        list.remove("Anna");
        //Removendo com base na posição
        list.remove(1); //remove Alex
        //Filtrar REMOVENDO com base em predicado
        list.removeIf( x -> x.charAt(0) == 'P');//removendo todos que começam com P. obs: aspas dupls da ruim

        //tamanho da lista
        System.out.println(list.size());
        for (String name : list){
            System.out.println("nome: "+name);
        }

        //posição de um elemento na lista (indexOf)
        System.out.println("Index of Bob: " + list.indexOf("Bob"));
        System.out.println("Index of Jeremias: " + list.indexOf("Jeremias"));//elementos que não existem ficam com index negativo

        //Filtrar MANTENDO com base em predicado-> tudo que começa com M
        //solução proposta: criar uma nova lista, converter para stream, aplicar um filtro e converter para list
        List<String> result1 = list.stream().filter(x -> x.charAt(0) == 'M').collect(Collectors.toList());

        for (String name : result1){
            System.out.println("nome solução professor: "+name);
        }

        //Minha alternativa: remover o que não começa com M
        list.removeIf(x -> x.charAt(0) !='M');
        for (String name : list){
            System.out.println("nome minha solução: "+name);
        }

        //Encontrar elemento com base em predicado

        list.add("Rafael");
        list.add("Ricardo");
        list.add("Renata");
        list.add("Raissa");

        //Encontraremos o primeiro elemento com a letra R
        String camarada = list.stream().filter(s->s.charAt(0) =='R').findFirst().orElse(null);
        System.out.println(camarada);
        String camarada2 = list.stream().filter(s->s.charAt(0) =='J').findFirst().orElse(null);
        System.out.println(camarada2);
    }
}
