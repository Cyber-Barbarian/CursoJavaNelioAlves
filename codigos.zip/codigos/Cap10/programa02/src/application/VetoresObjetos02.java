package Cap10.programa02.src.application;

import Cap10.programa02.src.entities.Product;

import java.util.Locale;
import java.util.Scanner;

public class VetoresObjetos02 {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a quantidade de produtos:");
        int n = sc.nextInt();
        System.out.println("");
        //criando um vetor que armazenará objetos do tipo Product
        Product[] vect =  new Product[n];

        // cada casinha do vetor será um objeto
        for (int i = 0; i<n; i+=1){
            System.out.printf("Digite o nome do produto %d:%n",i+1);
            String nomeProduto = sc.next();
            System.out.printf("Digite o preço do produto %s:%n", nomeProduto);
            double precoProduto = sc.nextDouble();

            //Criando o objeto tipo Product para a posição i
            vect[i] = new Product(nomeProduto,precoProduto);

            System.out.printf("Produto cadastrado: %s%nPreço:%.2f%n%n",vect[i].getName(),vect[i].getPrice());

        }

        double mediaPrecos = Product.MediaVetor(vect,n);
        System.out.println("Média de preços: R$ "+mediaPrecos);

        sc.close();
    }
}
