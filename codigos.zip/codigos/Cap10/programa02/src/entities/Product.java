package Cap10.programa02.src.entities;

public class Product {
    private String name;
    private double price;

    //clicando com o direito -> generate -> podemos criar construtores e getters/setters

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    //métodos
    public static double MediaVetor(Product[] vect, int n){
        double soma = 0.0;
        for(int j=0; j < n ; j++){
            soma += vect[j].getPrice();
        }
        double media = soma/n;
        return media;
    }
}
