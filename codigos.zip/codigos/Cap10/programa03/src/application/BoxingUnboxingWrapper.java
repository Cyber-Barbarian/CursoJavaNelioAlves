package Cap10.programa03.src.application;

public class BoxingUnboxingWrapper {
    public static void main(String[] args) {
        //É o processo de conversão de um objeto tipo valor para um objeto
        //tipo referência compatível
        int x = 20;
        Object obj = x;
        System.out.println(obj);

        //É o processo de conversão de um objeto tipo referência para um
        //objeto tipo valor compatível
        int y = (int) obj;
        System.out.println(y);

        //Wrapper : São classes referência equivalentes aos tipos primitivos, mas que aceitam null
        // e recursos de orientação a objeto, e que se comportam de
        //maneira explícita com relação ao compilador, sem necessidades de cast
        //ex Integer -> aneita numeros inteiros e null
        //é bom usar wrapper em coisas do tipo cadastro
        int x2 = 20;
        Integer obj2 = x2;
        int y2 = obj2; // não precisamos mais de cast
        System.out.println(y2);
    }
}
