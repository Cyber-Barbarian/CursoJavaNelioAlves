package Cap10.programa01.src.entities;

public class VectorOperations {
    public static double MediaVetor(double[] vect, int n){
        double soma = 0.0;
        for(int j=0; j < n ; j++){
            soma += vect[j];
        }
        double media = soma/n;
        return media;
    }
}
