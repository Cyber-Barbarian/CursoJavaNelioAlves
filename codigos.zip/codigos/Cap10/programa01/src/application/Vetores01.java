package Cap10.programa01.src.application;

import Cap10.programa01.src.entities.VectorOperations;

import java.util.Locale;
import java.util.Scanner;

public class Vetores01 {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite a quantidade de pessoas:");
        int n = sc.nextInt();
        //declaração de vetor => "tipo"[] nome = new "tipo"["tamanho"]
        double[] vect = new double[n];
        System.out.println("Digite as respectivas alturas das " + n + " pessoas:");
        for (int i = 0; i < n; i++) {
            vect[i] = sc.nextDouble();
        }

        //media
        double mediaVetor = VectorOperations.MediaVetor(vect,n);

        System.out.printf("A média de alturas é de %.2f metros.",mediaVetor);

        sc.close();
    }

}
