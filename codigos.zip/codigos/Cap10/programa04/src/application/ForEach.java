package Cap10.programa04.src.application;

public class ForEach {
    public static void main(String[] args) {
        String[] vect = new String[] {"Maria","Bob","Alex"};
        System.out.println("laço for");
        for (int i=0;i<vect.length;i++){
            System.out.println("elemento "+(i+1)+" nome: "+vect[i]);
        }
        //for each
        System.out.println("laço for each");
        int j = 1;
        for (String name:vect){
            System.out.println("elemento "+j+" nome: "+name);
            j++;
        }

    }

}
