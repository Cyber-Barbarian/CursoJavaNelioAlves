package Cap10.programa06.src.application;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Matrizes {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);
        System.out.println("digite o tamanho da matriz quadrada");
        int tamanhoMatiz = sc.nextInt();
        //criando a matriz bidimensional
        int[][] mat = new int[tamanhoMatiz][tamanhoMatiz];
        //criando a lista dos valores da diagonal e negativos
        List<Integer> diagonal = new ArrayList<>();
        List<Integer> negativos = new ArrayList<>();

        //para popular a matriz vamos fazer 2 for: um pras linhas e outro para as colunas
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.println("digite o elemento na posição [" + (i+1) + "],[" + (j+1) + "]:");
                mat[i][j] = sc.nextInt();
                //negativos
                if (mat[i][j] < 0) {
                    negativos.add(mat[i][j]);
                }
                //diagonal principal
                if (i == j) {
                    diagonal.add(mat[i][j]);
                }

            }
        }
        System.out.println("Diagonal principal:");
        for (int elem : diagonal) {
            System.out.println(elem);
        }

        System.out.println("Valores Negativos: total = "+negativos.size());
        for (int elem : negativos) {
            System.out.println(elem);
        }

        sc.close();
    }
}






