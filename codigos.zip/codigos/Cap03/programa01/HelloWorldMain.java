package Cap03.programa01;

public class HelloWorldMain {
    public static void main(String[] args){
        System.out.println("Hello World");
    }
}
