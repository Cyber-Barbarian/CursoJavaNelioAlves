package Cap05.programa03;

import java.util.Scanner;

public class SwitchCase {
    public static void main(String[] args) {
        /*Fazer um programa para ler um valor inteiro de 1 a 7 representando um
        dia da semana (sendo 1=domingo, 2=segunda, e assim por diante).
        Escrever na tela o dia da semana correspondente, conforme exemplos.

         */
        Scanner sc = new Scanner(System.in);
        Integer dia;
        String diaDaSemana;


        System.out.println("Digite um numero referente ao dia da semana");
        dia = sc.nextInt();
        sc.nextLine();

        switch (dia){
            case 1:
                diaDaSemana = "domingo";
                break;
            case 2:
                diaDaSemana = "segunda-feira";
                break;
            case 3:
                diaDaSemana = "terça-feira";
                break;
            case 4:
                diaDaSemana = "quarta-feira";
                break;
            case 5:
                diaDaSemana = "quinta-feira";
                break;
            case 6:
                diaDaSemana = "sexta-feira";
                break;
            case 7:
                diaDaSemana = "sábado";
                break;
            default:
                diaDaSemana = "Não existe";
                break;

        }

        System.out.println("O dia da semana é: "+diaDaSemana);

        sc.close();


    }
}
